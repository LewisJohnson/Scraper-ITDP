﻿namespace api.DTOs
{
	public class ScraperPostDTO
	{
		public string Url { get; set; }
		public string Keywords { get; set; }
	}
}
